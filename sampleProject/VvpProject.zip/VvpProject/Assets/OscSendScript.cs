﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

using UnityOSC;
using UnityEngine.UI;

public class OscSendScript : MonoBehaviour
{

    void Start()
    {
        //OSCクライアントの初期化を行う。 
        //  サーバID（任意）
        //  サーバのIPアドレス（ViviprogrammerのIPアドレス）
        OSCHandler.Instance.clientInit("192.168.250.56");
    }

    void Update()
    {
        if (Input.GetKey(KeyCode.UpArrow))
        {
            GameObject ballObj = GameObject.Find("ball");

            GetComponent<Rigidbody2D>().gravityScale = 0;
            GetComponent<Rigidbody2D>().velocity = Vector2.zero;

            Vector2 tmpPos = ballObj.transform.position;
            ballObj.transform.position = new Vector2(tmpPos.x, tmpPos.y + 0.1f);
        }
        else if (Input.GetKeyDown(KeyCode.DownArrow))
        {
            GetComponent<Rigidbody2D>().gravityScale = 1;
        }
    }

    //OSC送信するメソッド
    void send(int sendValue)
    {
        //OSC送信を実行する。
        //以下引数説明
        //  サーバID（初期化時と合わせる）
        //  OSCアドレス（任意）
        //  送信する値
        OSCHandler.Instance.SendMessageToClient("/vvp", sendValue);
        Debug.Log("OSC send! " + sendValue);
    }

    void OnCollisionEnter2D(Collision2D col)
    {
        if (col.gameObject.name == "floor")
        {
            Vector3 velocity = col.relativeVelocity;
            send((int)Mathf.Floor(velocity.y));
        }
    }
}
