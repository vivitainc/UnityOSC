﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityOSC;
public class OscReceiveScript : MonoBehaviour
{
    private long lastTimeStamp;

    // Use this for initialization
    void Start()
    {
        OSCHandler.Instance.serverInit();
        lastTimeStamp = -1;
    }

    // Update is called once per frame
    void Update()
    {
        //  受信データの更新
        OSCHandler.Instance.UpdateLogs();
        //  受信データの解析
        foreach (KeyValuePair<string, ServerLog> item in OSCHandler.Instance.Servers)
        {
            for (int i = 0; i < item.Value.packets.Count; i++)
            {
                if (lastTimeStamp < item.Value.packets[i].TimeStamp)
                {
                    lastTimeStamp = item.Value.packets[i].TimeStamp;

                    //  OSCアドレスを取得
                    string address = (string)item.Value.packets[i].Address;

                    //  データ型を取得
                    string dataType = (string)item.Value.packets[i].Data[0];

                    // 受信データの値を取得
                    int dataValue = (int)item.Value.packets[i].Data[1];

                    // 処理の振り分けの例
                    if (address == "/vvp")
                    {
                        if (dataType == "bool")
                        {
                            if (dataValue == 1)
                            {
                                Debug.Log("アドレスが/vvp、データ型がデジタル、値がtrueのデータを受信しました。");
                            }
                            else
                            {
                                Debug.Log("アドレスが/vvp、データ型がデジタル、値がfalseのデータを受信しました。");
                            }
                        }
                        else
                        {
                            Debug.Log("アドレスが/vvp、データ型がアナログ、値が" + dataValue + "のデータを受信しました。");
                        }

                    }
                    else
                    {
                        Debug.Log("アドレスが" + address + "、データ型が" + dataType + "、値が" + dataValue + "のデータを受信しました。");
                    }
                }
            }
        }
    }
}